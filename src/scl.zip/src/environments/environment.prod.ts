export const environment = {
  production: true,
 // apiUrl: "http://192.168.10.221/SamsungAPI/"
 //apiUrl: "http://192.168.10.221:8080/"
 // apiUrl: "http://192.168.10.178/"
  //apiUrl: "http://107.111.61.93/"
 //apiUrl: "https://localhost:44364/"
 apiUrl: "http://localhost:5000/"
  
};
