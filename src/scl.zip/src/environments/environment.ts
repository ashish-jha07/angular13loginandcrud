// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
 //apiUrl: "http://107.111.61.93/"
 //apiUrl: "http://192.168.10.221:8080/"
 //apiUrl: "http://192.168.10.76/"
//apiUrl: "http://192.168.10.221/SamsungAPI/"
 apiUrl: "http://192.168.10.178/"
//apiUrl: "http://192.168.10.178/"
//apiUrl: "https://localhost:44364/"
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
