import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sapupload',
  templateUrl: './sapupload.component.html',
  styleUrls: ['./sapupload.component.scss']
})
export class SapuploadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
