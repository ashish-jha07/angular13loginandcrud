import { Injectable } from '@angular/core';
import {
  forEach
} from 'lodash';
//var lodash = require('lodash');
@Injectable({
  providedIn: 'root'
})
export class LodashService {

  constructor() { 
    
  }
}
