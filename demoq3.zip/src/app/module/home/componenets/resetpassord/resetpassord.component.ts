import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resetpassord',
  templateUrl: './resetpassord.component.html',
  styleUrls: ['./resetpassord.component.css']
})
export class ResetpassordComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
