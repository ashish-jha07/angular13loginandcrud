import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewactivity',
  templateUrl: './viewactivity.component.html',
  styleUrls: ['./viewactivity.component.css']
})
export class ViewactivityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
