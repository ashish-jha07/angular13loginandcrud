import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-editactivity',
  templateUrl: './add-editactivity.component.html',
  styleUrls: ['./add-editactivity.component.css']
})
export class AddEditactivityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
