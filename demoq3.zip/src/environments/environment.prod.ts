export const environment = {
  production: true,
  encryptKey  : '1234567898787878787878',
  apiEndpoint :  'https://reqres.in/api/'
};
